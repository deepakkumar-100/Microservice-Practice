package com.javainuse.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.List;

@Controller
public class ConsumerControllerClient {


    //Direct hit to producer services

   /* public void getEmployee() throws RestClientException, IOException {

        String baseUrl = "http://localhost:8080/employee";
    */

    // Using DisCoverClient to make it loosely coupled url

	/*
	@Autowired
	private DiscoveryClient discoveryClient;

	public void getEmployee() throws RestClientException, IOException {
		List<ServiceInstance> instances=discoveryClient.getInstances("employee-producer");
		ServiceInstance serviceInstance=instances.get(0);
		String baseUrl=serviceInstance.getUri().toString();
	*/

	//Using LoadBalancer

   /* @Autowired
    private LoadBalancerClient loadBalancer;

    public void getEmployee() throws RestClientException, IOException {
        ServiceInstance serviceInstance = loadBalancer.choose("employee-producer");
        System.out.println(serviceInstance.getUri());
        String baseUrl = serviceInstance.getUri().toString();
        baseUrl = baseUrl + "/employee";

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = null;
        response = restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
        System.out.println(" ------ " + response.getBody());
    }

    private static HttpEntity<?> getHeaders() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(headers);
    }*/

//Using Zuul proxy gateway

    @Autowired
    private DiscoveryClient discoveryClient;
    public void getEmployee() throws RestClientException, IOException {

        List<ServiceInstance> instances = discoveryClient.getInstances("EMPLOYEE-ZUUL-SERVICE");
        ServiceInstance serviceInstance = instances.get(0);

        String baseUrl = serviceInstance.getUri().toString();

        baseUrl = baseUrl + "/producer/employee";

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = null;
        try {
            response = restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
        } catch (Exception ex) {
            System.out.println(ex);
        }
        System.out.println(response.getBody());
    }

    private static HttpEntity<?> getHeaders() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(headers);
    }
}
